$(document).ready(function(){


$(".efecto-bounce").fadeIn("slow");




});