


  /*$(window).scroll(function() {        
    var scroll = $(window).scrollTop();
    if (scroll <= 0) {
       $(".menu-footer").removeClass("menu-flotante");    
    
     }else{
       $(".menu-footer").addClass("menu-flotante");
    }
});
*/
var scroll1 = 0;
$( window ).scroll(function() {
   var scroll2= $(window).scrollTop();
    
    if(scroll1<scroll2){
        $(".fixed-bottom").show();
    }else{
        $(".fixed-bottom").hide();
    }
    scroll1 = scroll2;
});



